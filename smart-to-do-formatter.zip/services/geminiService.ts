
import { GoogleGenAI, Type } from "@google/genai";
import { SmartTaskParse, Priority, Section } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function parseTaskText(text: string): Promise<SmartTaskParse> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Parse the following task description and extract structured information: "${text}".
      Identify the core task, the implied timeframe, and the priority (look for hints like "urgent", "!!", "asap", or "low").
      Timeframes:
      - "Today": mentioned "today", "now", "tonight"
      - "Tomorrow": mentioned "tmrw", "tomorrow", "next day"
      - "Next Week": mentioned "next week", specific days next week
      - "Later": mentioned "next month", "someday", "future"
      - "Inbox": no timeframe mentioned.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING, description: "The cleaned title of the task without the date/priority keywords." },
            priority: { 
              type: Type.STRING, 
              enum: [Priority.LOW, Priority.MEDIUM, Priority.HIGH],
              description: "The priority of the task." 
            },
            section: { 
              type: Type.STRING, 
              enum: [Section.TODAY, Section.TOMORROW, Section.NEXT_WEEK, Section.LATER, Section.INBOX],
              description: "The time section the task belongs to." 
            },
            dueDate: { type: Type.STRING, description: "A formatted date string if applicable (YYYY-MM-DD)." }
          },
          required: ["title", "priority", "section"]
        }
      }
    });

    const result = JSON.parse(response.text.trim());
    return result as SmartTaskParse;
  } catch (error) {
    console.error("Gemini Parsing Error:", error);
    // Fallback simple parsing
    return {
      title: text,
      priority: text.includes("!!") ? Priority.HIGH : Priority.MEDIUM,
      section: Section.INBOX
    };
  }
}
