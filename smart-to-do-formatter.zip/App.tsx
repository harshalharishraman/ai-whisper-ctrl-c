
import React, { useState, useEffect, useMemo } from 'react';
import { Task, Section, Priority } from './types';
import { TaskInput } from './components/TaskInput';
import { TaskItem } from './components/TaskItem';
import { 
  Calendar, 
  Clock, 
  Inbox, 
  Layout, 
  LayoutGrid, 
  Focus, 
  Zap, 
  CheckCircle,
  Menu,
  X,
  Target
} from 'lucide-react';

const App: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [focusMode, setFocusMode] = useState(false);
  const [activeSection, setActiveSection] = useState<Section | 'All'>('All');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // Persistence
  useEffect(() => {
    const saved = localStorage.getItem('smart_todo_tasks');
    if (saved) setTasks(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem('smart_todo_tasks', JSON.stringify(tasks));
  }, [tasks]);

  const addTask = (task: Task) => setTasks(prev => [task, ...prev]);
  const toggleTask = (id: string) => setTasks(prev => prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  const deleteTask = (id: string) => setTasks(prev => prev.filter(t => t.id !== id));

  const filteredTasks = useMemo(() => {
    let result = tasks;
    
    if (focusMode) {
      // Focus mode only shows Today + High Priority
      return result.filter(t => !t.completed && (t.section === Section.TODAY || t.priority === Priority.HIGH));
    }

    if (activeSection !== 'All') {
      result = result.filter(t => t.section === activeSection);
    }
    
    return result;
  }, [tasks, focusMode, activeSection]);

  const sections = [
    { id: 'All', icon: LayoutGrid, label: 'All Tasks' },
    { id: Section.TODAY, icon: Calendar, label: 'Today' },
    { id: Section.TOMORROW, icon: Clock, label: 'Tomorrow' },
    { id: Section.NEXT_WEEK, icon: Zap, label: 'Next Week' },
    { id: Section.LATER, icon: Target, label: 'Later' },
    { id: Section.INBOX, icon: Inbox, label: 'Inbox' },
  ];

  const stats = useMemo(() => ({
    total: tasks.length,
    completed: tasks.filter(t => t.completed).length,
    focus: tasks.filter(t => !t.completed && (t.section === Section.TODAY || t.priority === Priority.HIGH)).length
  }), [tasks]);

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      {/* Mobile Nav Overlay */}
      {!sidebarOpen && (
        <button 
          onClick={() => setSidebarOpen(true)}
          className="fixed bottom-6 left-6 z-50 p-3 bg-indigo-600 text-white rounded-full shadow-2xl md:hidden"
        >
          <Menu className="w-6 h-6" />
        </button>
      )}

      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-40 w-72 bg-white border-r border-slate-100 transition-transform duration-300 md:relative md:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex flex-col h-full p-6">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-100">
                <CheckCircle className="w-6 h-6" />
              </div>
              <h1 className="font-bold text-slate-800 text-lg">FocusFlow</h1>
            </div>
            <button onClick={() => setSidebarOpen(false)} className="md:hidden text-slate-400">
              <X className="w-6 h-6" />
            </button>
          </div>

          <nav className="flex-1 space-y-1">
            {sections.map(s => (
              <button
                key={s.id}
                onClick={() => { setActiveSection(s.id as any); setFocusMode(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium text-sm ${
                  !focusMode && activeSection === s.id 
                    ? 'bg-indigo-50 text-indigo-600 shadow-sm' 
                    : 'text-slate-500 hover:bg-slate-50 hover:text-slate-700'
                }`}
              >
                <s.icon className="w-5 h-5" />
                {s.label}
              </button>
            ))}
          </nav>

          <div className="mt-8 pt-8 border-t border-slate-50">
            <button
              onClick={() => setFocusMode(!focusMode)}
              className={`w-full flex items-center justify-between p-4 rounded-2xl transition-all ${
                focusMode 
                  ? 'bg-amber-500 text-white shadow-lg shadow-amber-200 ring-4 ring-amber-100' 
                  : 'bg-white border-2 border-slate-100 text-slate-700 hover:border-amber-200'
              }`}
            >
              <div className="flex items-center gap-3">
                <Focus className={`w-5 h-5 ${focusMode ? 'animate-pulse' : ''}`} />
                <span className="font-bold text-sm">Focus Mode</span>
              </div>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${focusMode ? 'bg-amber-600' : 'bg-slate-100 text-slate-500'}`}>
                {stats.focus}
              </span>
            </button>
          </div>

          <div className="mt-6 p-4 bg-slate-50 rounded-2xl">
            <h3 className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-3 px-1">Statistics</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500">Completion</span>
                <span className="font-bold text-slate-700">{stats.total ? Math.round((stats.completed / stats.total) * 100) : 0}%</span>
              </div>
              <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-indigo-500 transition-all duration-1000" 
                  style={{ width: `${stats.total ? (stats.completed / stats.total) * 100 : 0}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="flex-none bg-white border-b border-slate-100 px-8 py-6 flex items-center justify-between z-10">
          <div>
            <h2 className="text-2xl font-bold text-slate-800">
              {focusMode ? 'Deep Focus' : activeSection === 'All' ? 'My Board' : activeSection}
            </h2>
            <p className="text-slate-400 text-sm mt-0.5">
              {focusMode 
                ? 'Showing only today and high-priority tasks.' 
                : `You have ${filteredTasks.length} tasks to look at.`}
            </p>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
          <div className="max-w-3xl mx-auto">
            {!focusMode && <TaskInput onAddTask={addTask} />}

            <div className="space-y-6">
              {filteredTasks.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-20 text-center opacity-40">
                  <div className="w-20 h-20 bg-slate-200 rounded-3xl flex items-center justify-center mb-4">
                    <Layout className="w-10 h-10 text-slate-400" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-600">Nothing here yet</h3>
                  <p className="text-sm text-slate-400 max-w-xs mx-auto">
                    {focusMode ? "You're all caught up on critical tasks! Take a breath." : "Start by adding a task with natural language above."}
                  </p>
                </div>
              ) : (
                <div className="grid gap-2">
                  {filteredTasks.map(task => (
                    <TaskItem 
                      key={task.id} 
                      task={task} 
                      onToggle={toggleTask} 
                      onDelete={deleteTask} 
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
