
import React, { useState } from 'react';
import { Sparkles, Plus, Loader2 } from 'lucide-react';
import { parseTaskText } from '../services/geminiService';
import { Task, Priority, Section } from '../types';

interface TaskInputProps {
  onAddTask: (task: Task) => void;
}

export const TaskInput: React.FC<TaskInputProps> = ({ onAddTask }) => {
  const [text, setText] = useState('');
  const [isParsing, setIsParsing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || isParsing) return;

    setIsParsing(true);
    try {
      const parsed = await parseTaskText(text);
      const newTask: Task = {
        id: crypto.randomUUID(),
        title: parsed.title,
        originalText: text,
        priority: parsed.priority,
        section: parsed.section,
        completed: false,
        createdAt: Date.now(),
        dueDate: parsed.dueDate
      };
      onAddTask(newTask);
      setText('');
    } catch (err) {
      console.error(err);
    } finally {
      setIsParsing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="relative mb-8">
      <div className="relative group">
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Try 'Gym tmrw morning !!high' or 'Call mom next week'"
          disabled={isParsing}
          className="w-full bg-white border-2 border-slate-100 rounded-2xl py-4 pl-12 pr-16 text-slate-700 placeholder:text-slate-400 focus:outline-none focus:border-indigo-400 focus:ring-4 focus:ring-indigo-50 transition-all shadow-sm"
        />
        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors">
          <Sparkles className="w-5 h-5" />
        </div>
        <button
          type="submit"
          disabled={!text.trim() || isParsing}
          className="absolute right-3 top-1/2 -translate-y-1/2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-200 text-white p-2 rounded-xl transition-all shadow-lg shadow-indigo-200 disabled:shadow-none"
        >
          {isParsing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Plus className="w-5 h-5" />}
        </button>
      </div>
      <div className="mt-2 px-1 flex gap-2">
        <span className="text-[10px] text-slate-400 font-medium">✨ AI automatically detects time & priority</span>
      </div>
    </form>
  );
};
