
import React from 'react';
import { Task, Priority } from '../types';
import { CheckCircle2, Circle, AlertCircle, Clock, Trash2 } from 'lucide-react';

interface TaskItemProps {
  task: Task;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

const PriorityBadge = ({ priority }: { priority: Priority }) => {
  const styles = {
    [Priority.HIGH]: 'bg-rose-50 text-rose-600 border-rose-100',
    [Priority.MEDIUM]: 'bg-amber-50 text-amber-600 border-amber-100',
    [Priority.LOW]: 'bg-emerald-50 text-emerald-600 border-emerald-100',
  };

  return (
    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border uppercase tracking-wider ${styles[priority]}`}>
      {priority}
    </span>
  );
};

export const TaskItem: React.FC<TaskItemProps> = ({ task, onToggle, onDelete }) => {
  return (
    <div className={`group flex items-center justify-between p-3 mb-2 rounded-xl border transition-all duration-200 bg-white hover:shadow-md hover:border-indigo-100 ${task.completed ? 'opacity-60 grayscale' : 'border-slate-100'}`}>
      <div className="flex items-center gap-3 flex-1">
        <button 
          onClick={() => onToggle(task.id)}
          className="text-slate-400 hover:text-indigo-600 transition-colors"
        >
          {task.completed ? <CheckCircle2 className="w-5 h-5 text-indigo-500" /> : <Circle className="w-5 h-5" />}
        </button>
        <div className="flex flex-col">
          <span className={`text-sm font-medium ${task.completed ? 'line-through text-slate-400' : 'text-slate-700'}`}>
            {task.title}
          </span>
          <div className="flex items-center gap-2 mt-1">
            <PriorityBadge priority={task.priority} />
            {task.dueDate && (
              <span className="flex items-center gap-1 text-[10px] text-slate-400 font-medium">
                <Clock className="w-3 h-3" />
                {task.dueDate}
              </span>
            )}
          </div>
        </div>
      </div>
      
      <button 
        onClick={() => onDelete(task.id)}
        className="opacity-0 group-hover:opacity-100 p-2 text-slate-300 hover:text-rose-500 transition-all"
      >
        <Trash2 className="w-4 h-4" />
      </button>
    </div>
  );
};
