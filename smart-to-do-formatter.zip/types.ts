
export enum Priority {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high'
}

export enum Section {
  TODAY = 'Today',
  TOMORROW = 'Tomorrow',
  NEXT_WEEK = 'Next Week',
  LATER = 'Later',
  INBOX = 'Inbox'
}

export interface Task {
  id: string;
  title: string;
  originalText: string;
  priority: Priority;
  section: Section;
  completed: boolean;
  createdAt: number;
  dueDate?: string;
}

export interface SmartTaskParse {
  title: string;
  priority: Priority;
  section: Section;
  dueDate?: string;
}
